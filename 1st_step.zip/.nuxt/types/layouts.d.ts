import { ComputedRef, Ref } from 'vue'
export type LayoutKey = "lefe-side-bar" | "right-side-bar" | "default" | "footer" | "header"
declare module "E:/xampp_8.1.6/htdocs/new_resources/movie-site-next/nuxt-movie-ui/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    layout?: false | LayoutKey | Ref<LayoutKey> | ComputedRef<LayoutKey>
  }
}