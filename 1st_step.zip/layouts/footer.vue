<template>
    <div class="bg-gray-700 py-4 text-white text-center dark:bg-red-700 dark:text-black">
        @ Syed Kamruzzaman ::2023:: @
    </div>
</template>